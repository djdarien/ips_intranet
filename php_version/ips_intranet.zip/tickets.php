<?php
$file = 'data/tickets.json';
if (!file_exists('data')) mkdir('data', 0755, true);
$tickets = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $ticket = [
    'customer'=>$_POST['customer'],
    'address'=>$_POST['address'],
    'comments'=>$_POST['comments'],
    'timestamp'=>date('c')
  ];
  $tickets[] = $ticket;
  file_put_contents($file, json_encode($tickets, JSON_PRETTY_PRINT));
  header('Location: tickets.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ticket Tracker</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header><h1>Ticket Tracker</h1><a href="index.php">🏠 Home</a></header>
  <main>
    <form method="POST" action="tickets.php">
      <input name="customer" placeholder="Customer Name" required>
      <input name="address" placeholder="Site Address" required>
      <textarea name="comments" placeholder="Comments" required></textarea>
      <button type="submit">Submit Ticket</button>
    </form>
    <section>
      <h2>Archive</h2>
      <ul>
        <?php foreach(array_reverse($tickets) as $t): ?>
          <li><?=htmlspecialchars($t['timestamp']).' - '.htmlspecialchars($t['customer']).': '.htmlspecialchars($t['comments'])?></li>
        <?php endforeach; ?>
      </ul>
    </section>
  </main>
</body>
</html>
