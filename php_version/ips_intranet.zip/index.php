<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IPS Intranet</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <h1>Independent Phone Services Inc.</h1>
    <div id="datetime-weather"></div>
  </header>
  <nav>
    <a href="tickets.php">Ticket Tracker</a>
    <a href="parts.php">Parts Inventory</a>
    <a href="timeclock.php">Time Clock</a>
  </nav>
  <main>
    <p>Welcome to the IPS Intranet. Use the menu above to navigate.</p>
  </main>
  <script>
    setInterval(()=>{
      document.getElementById('datetime-weather').innerText =
        'Local Time (Nokomis, FL): ' + new Date().toLocaleString();
    },1000);
  </script>
</body>
</html>
