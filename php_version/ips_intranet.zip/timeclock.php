<?php
$file='data/logs.json'; if(!file_exists('data')) mkdir('data',0755,true);
$logs=file_exists($file)?json_decode(file_get_contents($file),true):[];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $logs[]= ['name'=>$_POST['name'],'type'=>$_POST['type'],'time'=>date('c')];
  file_put_contents($file,json_encode($logs,JSON_PRETTY_PRINT));
  if(isset($_POST['export'])){
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename="timelogs.csv"');
    $out=fopen('php://output','w'); fputcsv($out,['Name','Type','Time']);
    foreach($logs as $l) fputcsv($out,[$l['name'],$l['type'],$l['time']]); fclose($out); exit;
  }
  header('Location: timeclock.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Time Clock</title><link rel="stylesheet" href="styles.css">
</head>
<body>
  <header><h1>Time Clock</h1><a href="index.php">🏠 Home</a></header>
  <main>
    <form method="POST" action="timeclock.php">
      <input name="name" placeholder="Employee Name" required>
      <button name="type" value="IN" type="submit">Clock In</button>
      <button name="type" value="OUT" type="submit">Clock Out</button>
      <button name="export" value="1" type="submit">Export CSV</button>
    </form>
    <ul>
      <?php foreach(array_reverse($logs) as $l): ?>
        <li><?=htmlspecialchars($l['time']).' - '.htmlspecialchars($l['name']).' '.htmlspecialchars($l['type'])?></li>
      <?php endforeach;?>
    </ul>
  </main>
</body>
</html>
