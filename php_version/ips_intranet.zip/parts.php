<?php
$file='data/parts.json';
if (!file_exists('data')) mkdir('data',0755,true);
$parts = file_exists($file) ? json_decode(file_get_contents($file),true) : [];
if ($_SERVER['REQUEST_METHOD']==='POST'){
  $parts[]= ['name'=>$_POST['name'],'qty'=>intval($_POST['qty'])];
  file_put_contents($file,json_encode($parts,JSON_PRETTY_PRINT));
  header('Location: parts.php'); exit;
}
if (isset($_GET['export'])){
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment;filename="parts.csv"');
  $out = fopen('php://output','w'); fputcsv($out,['Name','Quantity']);
  foreach($parts as $p) fputcsv($out,[$p['name'],$p['qty']]); fclose($out); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Parts Inventory</title><link rel="stylesheet" href="styles.css">
</head>
<body>
  <header><h1>Parts Inventory</h1><a href="index.php">🏠 Home</a></header>
  <main>
    <form method="POST" action="parts.php">
      <input name="name" placeholder="Part Name" required>
      <input name="qty" type="number" placeholder="Quantity" required>
      <button type="submit">Add Part</button>
    </form>
    <a href="parts.php?export=1"><button>Export CSV</button></a>
    <ul>
      <?php foreach(array_reverse($parts) as $p): ?>
        <li><?=htmlspecialchars($p['name']).': '.htmlspecialchars($p['qty'])?></li>
      <?php endforeach;?>
    </ul>
  </main>
</body>
</html>
